<?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\Users\OHHJAY\Desktop\tribute\backend\resources\views/partials/success.blade.php ENDPATH**/ ?>