<?php
/**
 * tribute2
 * Olamiposi
 * 22/01/2021
 * 10:16
 * CREATED WITH PhpStorm
 **/
?>

<div class="memorial-view-bottom">

    <h5 class="memorial-view-heading">Post a tribute</h5>
    <?php if(auth()->user()): ?>
    <p class="memorial-view-login">
        <a href="<?php echo e(route('login')); ?>" class="memorial-view-link">Log in</a>
        to post a tribute for <?php echo e($detail->first_name. ' ' .$detail->last_name); ?>

    </p>
    <?php else: ?>
    <form>
    </form>

    <?php endif; ?>

</div><?php /**PATH C:\Users\OHHJAY\Desktop\tribute\backend\resources\views/partials/postTribute.blade.php ENDPATH**/ ?>