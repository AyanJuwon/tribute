<?php
/**
 * tribute2
 * Olamiposi
 * 15/12/2020
 * 21:10
 * CREATED WITH PhpStorm
 **/
?>



<?php $__env->startSection('title'); ?>
    Payment Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
  <main>
            <section class="dashboard profile-container">
                <div class="payment-top">
                    <h4 class="profile-heading">Payment Log</h4>

                </div>
                <table class="payment-table">
                    <thead class="payment-table__table-head">
                        <tr class="payment-table__table-row">
                            <th class="table-check-head">
                                <label class="table-check">
                                    <input type="checkbox">
                                    <span class="table-checkmark"></span>
                                </label>
                            </th>
                            <th class="payment-table__head-title">Memorial</th>
                            <th class="payment-table__head-title">Plan</th>
                            <th class="payment-table__head-title">Amount</th>
                            <th class="payment-table__head-title">Payment Date</th>
                            <th class="payment-table__head-title">Expiration Date</th>
                        </tr>
                    </thead>
                    <tbody class="payment-table__table-body">
                                 
                    <?php if(\App\Payment::countPayment() == 0): ?>
                        <h3 style="text-align: center;font-size: 30px">Nothing to show yet</h3>
                        <?php else: ?>
<?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="payment-table__table-row">
                            <td class="table-check-body">
                                <label class="table-check">
                                    <input type="checkbox">
                                    <span class="table-checkmark"></span>
                                </label>
                            </td>
                            <td class="payment-table__table-data"><?php echo e($detail->memorial->first_name. ' '.$detail->memorial->last_name); ?></td>
                            <td class="payment-table__table-data"><?php echo e($detail->memorial->plan_type); ?></td>
                            <td class="payment-table__table-data">
                                <?php if($detail->memorial->plan_type == 'free'): ?>
                                --
                                <?php else: ?><?php echo e($detail->amount); ?><?php endif; ?></td>
                            <td class="payment-table__table-data"><?php echo e($detail->memorial->created_at->toDateString()); ?></td>
                            <td class="payment-table__table-data"><?php echo e($detail->memorial->expiry_date->toDateString()); ?></td>
                        </tr>
                      
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>     </tbody>
                </table>
            </section>
        </main>
<?php $__env->stopSection(); ?>
                                
                   
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OHHJAY\Desktop\tribute\backend\resources\views/accounts/paymentdetails.blade.php ENDPATH**/ ?>