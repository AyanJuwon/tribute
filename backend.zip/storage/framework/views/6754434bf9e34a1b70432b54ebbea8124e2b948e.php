<?php
/**
 * tribute2
 * Olamiposi
 * 02/03/2021
 * 00:50
 * CREATED WITH PhpStorm
 **/
?>
<?php if(auth()->user()): ?>
    <?php if($tc != ''): ?>
        <?php if(session()->has('flash_notification.success') && \Carbon\Carbon::parse($tc->created_at)->diffInHours(\Carbon\Carbon::parse(\Carbon\Carbon::now()) >= '24')): ?>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#exampleModalCenter').modal();
    });
</script>
<?php endif; ?>
        <?php endif; ?>
        <?php endif; ?>
            <!-- Modal -->
            <div class="modal fade bd-example-modal-sm" id="exampleModalCenter" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header" style="background-color: #eeeeee">
                            <h3 style="font-size: 20px;font-weight: 900; color: #4d5965" class="modal-title" id="exampleSmallModalLabel">Upgrade your Subscription</h3>



                        </div>
                        <div class="modal-body">
                            <p class="text-muted" style="color: #4d5965">You registered a free memorial, upgrade to a paid memorial now!</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <a style="background-color: #4d5965" type="button" href="<?php echo e(route('memorials')); ?>" class="btn btn-primary">Let's go!</a>
                        </div>
                    </div>
                </div>
            </div>
























<?php /**PATH C:\Users\OHHJAY\Desktop\tribute\backend\resources\views/partials/subalert.blade.php ENDPATH**/ ?>