<?php
/**
 * tribute
 * Olamiposi
 * 13/10/2020
 * 19:51
 * CREATED WITH PhpStorm
 **/
?>
<aside class="col-md-3 col-sm-5 wow fadeInUp">

    <div class="container margin-bottom-50" style="background-color: #eeeeee; border-radius: 7px; ">
        <h4 style="font-size: 17px;" class="padding-top-10 text-center">Invite <?php echo e($detail->first_name); ?>'s Family and Friends: </h4>
        <div class="addthis_inline_share_toolbox_rxma text-center padding-top-20 padding-bottom-10"></div>

    </div>
    <div class="links margin-bottom-50">
        <a href="<?php echo e(route('tribute', $slug)); ?>">Tributes <i class="flaticon-arrows-1"></i></a>
        <a href="<?php echo e(route('stories', $slug)); ?>">Stories <i class="flaticon-arrows-1"></i></a>
        <a href="<?php echo e(route('life', $slug)); ?>">Life <i class="flaticon-arrows-1"></i></a>
        <a href="<?php echo e(route('gallery', $slug)); ?>">Gallery <i class="flaticon-arrows-1"></i></a>
    </div>


    <?php if($detail->music != 'NULL'): ?>
        <div class="text-center">
            <audio id="myAudio" controls autoplay controlsList="nodownload">
                <source src="<?php echo e(asset('uploads/music/'.$detail->music)); ?>" type="audio/mpeg">
            </audio>
        </div>

        <div class="padding-bottom-20"></div>
        <?php endif; ?>

    <div class="container margin-bottom-50" style="background-color: #eeeeee; border-radius: 7px">
        <h3 style="text-decoration: underline; text-align: center" class="padding-top-10">Recent Activties</h3>
        <?php if(\App\ActiviesLog::countActivity($slug) == 0): ?>
            <br>
            <h3 style="text-align: center; color: #c0a16b">Nothing to show Yet</h3>
            <div class="padding-bottom-20"></div>
        <?php else: ?>
        <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($act->subject_type == 'App\Stories'): ?>
                    <p><?php echo e($act->users->name); ?>, <a href="<?php echo e(route('stories', $slug)); ?>" style="color: #c0a16b;"> <?php echo e($act->description); ?></a>, <?php echo e($act->created_at->format('h:i A')); ?></p>
                <?php elseif($act->subject_type == 'App\Tribute'): ?>
                    <p><?php echo e($act->users->name); ?>, <a href="<?php echo e(route('tribute', $slug)); ?>" style="color: #c0a16b;"> <?php echo e($act->description); ?></a>, <?php echo e($act->created_at->format('h:i A')); ?></p>
                    <?php else: ?>
                    <p><?php echo e($act->users->name); ?>, <a href="<?php echo e(route('gallery', $slug)); ?>" style="color: #c0a16b;"> <?php echo e($act->description); ?></a>, <?php echo e($act->created_at->format('h:i A')); ?></p>
                <?php endif; ?>

            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
    </div>

    <div class="container margin-bottom-50" style="background-color: #eeeeee; border-radius: 7px">
            <br>
            <h3 style="text-align: center; color: #c0a16b"><?php echo e(number_format($detail->page_views)); ?> View(s)</h3>
            <div class="padding-bottom-20"></div>
    </div>

    <div class="container margin-bottom-50" style="background-color: #eeeeee; border-radius: 7px">
        <br>
        <h3 style="text-align: center; color: #c0a16b;font-size: 22px">Created By <?php echo e($detail->users->name); ?></h3>
        <div class="padding-bottom-20"></div>
    </div>
</aside>
<?php /**PATH C:\Users\OHHJAY\Desktop\tribute\backend\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>