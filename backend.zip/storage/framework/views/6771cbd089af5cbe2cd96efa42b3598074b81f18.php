

<?php $__env->startSection('title'); ?>
    Login
<?php $__env->stopSection(); ?>
<?php $__env->startSection('side-text'); ?>
    
                    <h1 class="box__text">Create <br> beautiful <br> memories.</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-function'); ?>
      <h2 class="section-heading">Sign In</h2>
                        <p class="section-sub-heading">Don’t have an account? <a href="<?php echo e(route('register')); ?>">Sign Up</a></p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('auth-form'); ?>

                    <form method="POST" class="form-sign" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>



                        <div class="form-sign__group">
                            <label class="form-sign__label" for="email">Email</label>
                            <input id="email" class="form-sign__input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Enter your email" type="email" >

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                      

                        <div class="form-sign__group">
                            <label class="form-sign__label" for="password">Password</label>
                            <input id="password" class="form-sign__input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Enter your password" type="password">
                            <span class="form-sign__iconPass">
                                    <img src="/assets/img/show-password.svg" id="show">
                                    <img src="/assets/img/hide-password.svg" id="hide">
                                </span>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                         <input type="submit" value="sign in" class="form-sign__sign-up">
                    
                
                    </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OHHJAY\Desktop\tribute\backend\resources\views/auth/login.blade.php ENDPATH**/ ?>