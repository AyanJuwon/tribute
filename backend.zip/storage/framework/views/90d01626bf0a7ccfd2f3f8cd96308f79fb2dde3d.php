<?php
/**
 * tribute2
 * Olamiposi
 * 26/11/2020
 * 19:40
 * CREATED WITH PhpStorm
 **/
?>


<?php $__env->startSection('title'); ?>
    Memorials
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
     <div class="memorials">
            <div class="memorial-view-container">
                <div class="memorials-top">
                    <h3 class="memorials-heading">Memorials</h3>
                    <form action="#" class="memorials-search">
                        <img src="../../assets/img/search-icon.svg" class="memorials-search__icon">
                        <input type="text" class="memorials-search__input" placeholder="Search public memorials">
                    </form>
                    <a href="<?php echo e(route('createMemorial')); ?>" class="memorials-button">
                        <img src="../../assets/img/plus-icon.svg">
                        <span>Create Memorial</span>
                    </a>
                </div>
    
                <div class="memorials-content">
                    <div class="memorials-content__left">
                         <?php if($count == 0): ?>--}}
                       <div class="text-center">
                           <div class="padding-bottom-60"></div>
                           <h3>Nothing to show yet, <a href="<?php echo e(route('createMemorial')); ?>" style="color:#c0a16b;"> create a memorial</a></h3>
                       </div>
                   <?php else: ?>
                   <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tribute">
                            <div class="tribute__owner">
                                <p class="tribute__initials"><?php echo e($detail->getInitials($detail->users->name)); ?></p>
                                <div class="tribute__poster">
                                    <h6 class="tribute__name"><?php echo e($detail->users->name); ?></h6>
                                    <div class="tribute__line">
                                        <p class="tribute__user"><?php echo e($detail->users->role); ?></p>
                                        <span class="dot-status"></span>
                                        <div class="tribute__date"><?php echo e($detail->created_at->toDateString()); ?></div>
                                    </div>
                                </div>
                            </div>

                            <div class="tribute-details">
                                <div class="tribute-details__left">
                                    <div class="tribute-details__img-btn">
                                        <img src="../../assets/img/memorial-img-1.png" alt="Memorial Image" class="tribute-details__img">
                                        <a href="<?php echo e(route('viewMemorial',$detail->slug)); ?>" class="tribute-details__btn">Visit Memorial</a>
                                    </div>
                                </div>
                                <div class="tribute-details__right">
                                    <div class="row-1">
                                        <h6 class="tribute-details__fullname"><?php echo e($detail->first_name. ' ' . $detail->last_name); ?></h6>
                                        <p class="tribute-details__date-range"><?php echo e($detail->born_date->toDateString()); ?> - <?php echo e($detail->passed_away_date->toDateString()); ?></p>
                                        <blockquote class="tribute-details__quote">
                                            "Let the Memory of Magbodi Johnson be with us forever"
                                            <?php echo e($detail->personal_phrase); ?>

                                        </blockquote>
                                    </div>
                                    <div class="row-2">
                                        <p class="tribute-details__text">
                                            This memorial website was created in memory of our loved one, Magbodi Johnson 80 years old , born on Sept 02, 1980 and passed away on Aug 19, 2021. We will remember him forever.
                                            <?php echo e($detail->main_section_text); ?>

                                        </p>
                                        <div class="tribute-details__info">
                                            <p class="tribute-details__views"><?php echo e($detail->page_views); ?> Views</p>
                                            <span class="dot-status"></span>
                                            <p class="tribute-details__tribute-number"><?php echo e(\App\Tribute::getTributeBySlug($detail->slug)); ?> Tributes</p>
                                        </div>
                                    </div>
                                    <div class="row-3">
                                        <div class="tribute-details__socials">
                                            <a href="#" class="tribute-details__link"><img src="<?php echo e(asset('assets/img/ig-memorial.svg')); ?>" alt="instagram" class="tribute-details__icon"></a>
                                            <a href="#" class="tribute-details__link"><img src="<?php echo e(asset('assets/img/whatsapp-memorial.svg')); ?>" alt="whatsapp" class="tribute-details__icon"></a>
                                            <a href="#" class="tribute-details__link"><img src="<?php echo e(asset('assets/img/whatsapp-memorial.svg')); ?>" alt="twitter" class="tribute-details__icon"></a>
                                            <a href="#" class="tribute-details__link"><img src="<?php echo e(asset('assets/img/facebook-memorial.svg')); ?>" alt="facebook" class="tribute-details__icon"></a>
                                        </div>
    
                                        <div class="tribute-details__copy">
                                            <a href="<?php echo e(route('viewMemorial',$detail->slug)); ?>" id="copy-content"><?php echo e($detail->slug); ?>/createtribute.com</a>
                                            <button id="btn-copy">
                                                <img src="<?php echo e(asset('assets/img/copy-icon.svg')); ?>" alt="Copy Icon">
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
                       
                    </div>
                    <aside class="memorials-content__right">
                        
                            
                        
                        <h4 class="aside-heading">Most Viewed Tribute</h4>
                        <div class="top-tribute">
                            <div class="top-tribute__card-img">
                                <img src="../../assets/img/top-memorial-img.png" alt="Most Viewed Tribute" class="top-tribute__img">
                                <a href="<?php echo e(route('viewMemorial',$mostViewed->slug)); ?>" class="top-tribute__btn">Visit Memorial</a>
                            </div>
                            <div class="top-tribute__content">
                                <div class="top-tribute__details">
                                    <div class="top-tribute__box">
                                        <p class="top-tribute__initials"><?php echo e($mostViewed->getInitials($mostViewed->users->name)); ?></p>
                                           <div class="top-tribute__poster">
                                            <h6 class="top-tribute__name"><?php echo e($mostViewed->users->name); ?></h6>
                                            <div class="top-tribute__line">
                                                <p class="top-tribute__user"><?php echo e($mostViewed->users->role); ?></p>
                                                <span class="dot-status"></span>
                                                <div class="top-tribute__date"><?php echo e($mostViewed->created_at->toDateString()); ?></div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="top-tribute__top">
                                        <h6 class="top-tribute__fullname"><?php echo e($mostViewed->first_name. ' '. $mostViewed->last_name); ?></h6>
                                        <p class="top-tribute__date-range"><?php echo e($mostViewed->born_date->toDateString()); ?> - <?php echo e($mostViewed->passed_away_date->toDateString()); ?></p>
                                    </div>
                                    <div class="top-tribute__bottom">
                                        <p class="top-tribute__text">
                                            This memorial website was created in memory of our loved one, Magbodi Johnson 80 years old , born on Sept 02, 1980 and passed away on Aug 19, 2021. We will remember him forever.
                                        </p>
                                        <div class="top-tribute__info">
                                            <p class="top-tribute__views"><?php echo e($mostViewed->page_views); ?> Views</p>
                                            <span class="dot-status"></span>
                                            <p class="top-tribute__tribute-number"><?php echo e(\App\Tribute::getTributeBySlug($mostViewed->slug)); ?> Tributes</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </aside>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OHHJAY\Desktop\tribute\backend\resources\views/accounts/memorials.blade.php ENDPATH**/ ?>