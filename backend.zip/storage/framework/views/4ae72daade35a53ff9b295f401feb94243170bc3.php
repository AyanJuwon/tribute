<?php
/**
 * tribute2
 * Olamiposi
 * 26/11/2020
 * 19:58
 * CREATED WITH PhpStorm
 **/
?>

<div class="side-widget margin-bottom-50">
    <div class="links margin-bottom-50">

        <a href="<?php echo e(route('memorials')); ?>">My Memorials <i class="flaticon-arrows-1"></i></a>
        <a href="<?php echo e(route('myaccount', auth()->user()->id)); ?>">Manage Account <i class="flaticon-arrows-1"></i></a>
        <a href="<?php echo e(route('payment')); ?>">Manage Payment <i class="flaticon-arrows-1"></i></a>
        <a href="<?php echo e(route('forPassword', auth()->user()->id)); ?>">Change Password <i class="flaticon-arrows-1"></i></a>
    </div>
</div>
<?php /**PATH C:\Users\OHHJAY\Desktop\tribute\backend\resources\views/partials/user.blade.php ENDPATH**/ ?>