<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>

    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('img/favi.png')); ?>">
    <script src="https://use.fontawesome.com/a5fa0ac781.js"></script>


    <!-- Title -->
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!---Fontawesome css-->
    <link href="<?php echo e(asset('assets/plugins/fontawesome-free/css/all.min.css')); ?>'" rel="stylesheet">

    <!---Ionicons css-->
    <link href="<?php echo e(asset('assets/plugins/ionicons/css/ionicons.min.css')); ?>'" rel="stylesheet">

    <!---Typicons css-->
    <link href="<?php echo e(asset('assets/plugins/typicons.font/typicons.css')); ?>" rel="stylesheet">

    <!---Feather css-->
    <link href="<?php echo e(asset('assets/plugins/feather/feather.css')); ?>" rel="stylesheet">

    <!---Falg-icons css-->
    <link href="<?php echo e(asset('assets/plugins/flag-icon-css/css/flag-icon.min.css')); ?>" rel="stylesheet">

    <!---Style css-->
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/custom-style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/skins.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/dark-style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/custom-dark-style.css')); ?>" rel="stylesheet">


</head>

<body>
<!-- Loader -->
<div id="global-loader">
    <img src="<?php echo e(asset('assets/img/loader.svg')); ?>" class="loader-img" alt="Loader">
</div>
<!-- End Loader -->
<?php echo $__env->yieldContent('content'); ?>

<!-- End Page -->
<!-- Jquery js-->
<script src="<?php echo e(asset('assets/plugins/jquery/jquery.min.js')); ?>"></script>

<!-- Bootstrap js-->
<script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- Ionicons js-->
<script src="<?php echo e(asset('assets/plugins/ionicons/ionicons.js')); ?>"></script>

<!-- Rating js-->
<script src="<?php echo e(asset('assets/plugins/rating/jquery.rating-stars.js')); ?>"></script>


<!-- Custom js-->
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>




</body>

</html>
<?php /**PATH C:\Users\OHHJAY\Desktop\tribute\backend\resources\views/layouts/app.blade.php ENDPATH**/ ?>