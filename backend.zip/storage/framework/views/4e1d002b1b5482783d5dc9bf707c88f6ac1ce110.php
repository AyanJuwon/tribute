<?php
/**
 * tribute2
 * Olamiposi
 * 21/12/2020
 * 22:12
 * CREATED WITH PhpStorm
 **/
?>


<?php $__env->startSection('title'); ?>
    Memorial Detail
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div>
                <h2 class="main-content-title tx-24 mg-b-5"><?php echo e(\App\Memorial::fullname($mem)); ?></h2>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Memorial Detail</li>
                </ol>
            </div>
        </div>
        <!-- End Page Header -->
        <!-- Row -->
        <div class="row">
            <div class="col-lg-4 col-md-12">
                <?php echo $__env->make('partials.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('partials.list_error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="card custom-card">
                    <div class="card-body text-center">
                        <div class="main-profile-overview widget-user-image text-center">
                            <div class="main-img-user"><img alt="avatar" src="<?php echo e(asset('uploads/memorial/'.$mem->picture)); ?>"></div>
                        </div>
                        <div class="item-user pro-user">
                            <h4 class="pro-user-username text-dark mt-2 mb-0"><?php echo e(\App\Memorial::fullname($mem)); ?></h4>
                            <p class="pro-user-desc text-muted mb-1"><?php echo e(\Carbon\Carbon::parse($mem->born_date)->year); ?> - <?php echo e(\Carbon\Carbon::parse($mem->passed_away_date)->year); ?></p>
                        </div>
                    </div>
                    <div class="card-footer p-0">
                        <div class="row text-center">
                            <div class="col-sm-12">
                                <div class="description-block">
                                    <h5 class="description-header mb-1" style="padding: 0"><?php echo e(number_format($mem->page_views)); ?></h5>
                                    <span class="text-muted">Page Views</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 col-md-12">
                <div class="card custom-card main-content-body-profile">
                    <nav class="nav main-nav-line">
                        <a class="nav-link active" data-toggle="tab" href="#tab1over">Overview</a>
                    </nav>
                    <div class="card-body tab-content h-100">
                        <div class="tab-pane active" id="tab1over">
                            <div class="main-content-label tx-13 mg-b-20">
                                Website Information
                            </div>
                            <div class="table-responsive ">
                                <table class="table row table-borderless">
                                    <tbody class="col-lg-12 col-xl-6 p-0">
                                    <tr>
                                        <td><strong>Full Name :</strong> <?php echo e(\App\Memorial::fullname($mem)); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Date of Birth :</strong> <?php echo e($mem->born_date->format('M d, Y')); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Date of Death :</strong> <?php echo e($mem->passed_away_date->format('M d, Y')); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Relationship :</strong> <?php echo e($mem->relationship); ?></td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <?php if($mem->active == true): ?>
                                            <div class="btn-group btn-hspace text-center" style="text-align: center">
                                                <a onclick="handleDeletee(<?php echo e($mem->id); ?>)" class="btn btn-secondary dropdown-toggle" style="background-color: #65594d;color:white;text-align: center;" type="button">Suspend</a>

                                            </div>
                                                <?php else: ?>
                                                <div class="btn-group btn-hspace text-center" style="text-align: center">
                                                    <a onclick="handleDelete(<?php echo e($mem->id); ?>)" class="btn btn-secondary dropdown-toggle" style="background-color: #65594d;color:white;text-align: center;" type="button">Activate</a>

                                                </div>
                                                <?php endif; ?>
                                        </td>
                                    </tr>
                                    </tbody>
                                    <tbody class="col-lg-12 col-xl-6 p-0">
                                    <tr>
                                        <td><strong>Website :</strong> <a href="<?php echo e('http://tributetoaloveone.com/'.$mem->slug); ?>"><?php echo e($mem->slug); ?>.tributetoaloveone.com</a></td>
                                    </tr>

                                    <tr>
                                        <td><strong>Created By :</strong> <?php echo e($mem->users->name); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Plan :</strong> <?php echo e(ucwords($mem->plan_type)); ?></td>
                                    </tr>
                                    <?php if($mem->plan_type == 'lifetime'): ?>
                                    <tr>
                                        <td><strong>Expiring Date :</strong> NULL </td>
                                    </tr>
                                        <?php else: ?>
                                        <tr>
                                            <td><strong>Expiring Date :</strong> <?php echo e($mem->expiry_date->format('M, d Y')); ?></td>
                                        </tr>
                                        <?php endif; ?>

                                    </tbody>
                                </table>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <?php echo $__env->make('partials.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        function handleDelete(id){
            $('#activateMemorialModal').modal({backdrop: 'static',keyboard : false});
            var form = document.getElementById('activateMemorialForm');
            var url = '<?php echo e(route('memorial.activate', [':id'])); ?>';
            url = url.replace(':id', id);
            form.action = url;
        }
    </script>
    <script>
        function handleDeletee(id){
            $('#deactivateMemorialModal').modal({backdrop: 'static',keyboard : false});
            var form = document.getElementById('deactivateMemorialForm');
            var url = '<?php echo e(route('suspend', [':id'])); ?>';
            url = url.replace(':id', id);
            form.action = url;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OHHJAY\Desktop\tribute\backend\resources\views/admin/showMem.blade.php ENDPATH**/ ?>