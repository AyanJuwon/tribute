<?php
/**
 * tribute
 * Olamiposi
 * 12/10/2020
 * 21:13
 * CREATED WITH PhpStorm
 **/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="../../assets/css/style.css">
    <script type="module" src="../../assets/js/script.js" defer></script>
    <title>Tribute <?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
    <header class="header">
        <img src="/assets/img/logo.png" alt="Logo" class="logo">
        <nav class="main-nav">
            <ul class="main-nav__list">
                <li><a href="/index.html" class="main-nav__link link--active">Home</a></li>
                <li><a href="#" class="main-nav__link">Pricing</a></li>
                <li><a href="#" class="main-nav__link">FAQ</a></li>
                <li><a href="/main/landingPage/memorials.html" class="main-nav__link">Memorials</a></li>
            </ul>
            <ul class="main-nav__cta">
                <li><a href="<?php echo e(route('login')); ?>" class="nav-cta-light">Sign in</a></li>
                <li><a href="<?php echo e(route('register')); ?>" class="nav-cta-dark">Sign up</a></li>
            </ul>
        </nav>
    </header>

<body>
<div class="wrapper">

    <header class="header4 header5">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-8">
                    <a href="<?php echo e(route('welcome', $slug)); ?>" class="navbar-brand"><img src="<?php echo e(asset('img/logo2.png')); ?>" class="img-responsive" alt=""></a>
                </div>
                <div class="col-md-9 col-sm-9 col-xs-4">
                    <div class="clearfix"></div>
                    <nav class="navbar navbar-default">
                        <button type="button" class="navbar-toggle collapsed collapse-icon" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                            <span>
                <em></em>
                <em></em>
                <em></em>
            </span>
                        </button>
                        <div id="navbar" class="navbar-collapse collapse" >
                            <ul class="nav navbar-nav don">
                                <li class="active"><a href="<?php echo e(route('welcome', $slug)); ?>">About</a></li>
                                <li><a href="<?php echo e(route('life', $slug)); ?>">Life</a></li>
                                <li><a href="<?php echo e(route('gallery', $slug)); ?>">Gallery</a></li>
                                <li><a href="<?php echo e(route('stories', $slug)); ?>">Stories</a></li>
                                <li><a href="<?php echo e(route('tribute', $slug)); ?>">Tributes</a></li>
                                <?php if(auth()->user()): ?>
                                    <li class="dropdown dropdown-normal">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">My Account <span class="fa fa-angle-down"></span></a>
                                        <ul class="dropdown-menu dropdown-menu-v3">
                                            <li><a href="<?php echo e(route('memorials')); ?>">My Memorials</a></li>
                                            <li><a href="<?php echo e(route('myaccount', auth()->user()->id)); ?>">Account Details</a></li>
                                        </ul>
                                    </li>
                                <?php endif; ?>
                                <?php if(!auth()->user()): ?>
                                    <li>
                                        <a href="<?php echo e(route('login')); ?>">
                                            <i class="fa fa-user-circle mr-1"></i> Sign In</a>
                                    </li>
                                    <li><a href="<?php echo e(route('register')); ?>">Sign Up</a></li>
                                <?php endif; ?>

                                <?php if(auth()->user()): ?>
                                    <li><a href="<?php echo e(route('logout')); ?>"
                                           onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                            <i class="fa fa-sign-out mr-1"></i> Logout
                                        </a></li>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                <?php endif; ?>


                            </ul>
                        </div>
                        <!--/.nav-collapse -->
                        <!--/.container-fluid -->
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <div class="clearfix"></div>

    <?php echo $__env->yieldContent('content'); ?>



</div>
<footer class="wow fadeInUpBig">
    <div class="container padding-top-40">
        <div class="row">
            <div class="col-md-4 col-sm-6 footer-contact margin-bottom-40">
                <h4 style="font-weight: lighter">Tribute Page</h4>
                <a href="<?php echo e(route('welcome', $slug)); ?>" style="color: white;">About</a>
                <br>
                <div class="padding-bottom-20"></div>
                <a href="<?php echo e(route('life', $slug)); ?>" style="color: white;">Life</a>
                <br>
                <div class="padding-bottom-20"></div>
                <a href="<?php echo e(route('gallery', $slug)); ?>" style="color: white;">Gallery</a>
                <br>
                <div class="padding-bottom-20"></div>
                <a href="<?php echo e(route('stories', $slug)); ?>" style="color: white;">Stories</a>
                <br>
                <div class="padding-bottom-20"></div>
                <a href="<?php echo e(route('tribute', $slug)); ?>" style="color: white;">Tributes</a>
            </div>
            <div class="col-md-4 col-push-3 col-sm-6 footer-contact margin-bottom-40">
                <h4 style="font-weight: lighter">Quick Links</h4>
                <a href="<?php echo e(route('landing')); ?>" style="color: white;">Home</a>
                <br>
                <div class="padding-bottom-20"></div>
                <a href="<?php echo e(route('about')); ?>" style="color: white;">About Us</a>
                <br>
                <div class="padding-bottom-20"></div>
                <a href="<?php echo e(route('contact')); ?>" style="color: white;">Contact Us</a>
                <br>
                <div class="padding-bottom-20"></div>
                <a href="<?php echo e(route('howitworks')); ?>" style="color: white;">How it works</a>
                <br>
                <div class="padding-bottom-20"></div>
                <a href="<?php echo e(route('pricing')); ?>" style="color: white;">Plans & Features</a>
            </div>

            <div class="col-md-4 col-push-3 col-sm-6 footer-contact margin-bottom-40">
                <h4 style="font-weight: lighter">Legal</h4>
                <a href="<?php echo e(route('terms')); ?>" style="color: white">Terms & Conditions</a>
                <br>
                <div class="padding-bottom-20"></div>
                <a href="<?php echo e(route('pandp')); ?>" style="color: white">Privacy Policy</a>
                <br>
                <div class="padding-bottom-20"></div>
                <a href="https://codefixbug.com" target="_blank" style="color: white">About Parent Company</a>
                <br>
                <div class="padding-bottom-20"></div>
                <a href="<?php echo e(route('faq')); ?>" style="color: white">FAQ's</a>
        </div>
    </div>

    <div class="container">
        <div class="footer-bottom text-center">
            Copyright &copy; <?php echo e(\Carbon\Carbon::now()->year); ?> <a style="color: #c0a16b" href="https://tributetoaloveone.com">Tributetoaloveone.com</a> - Powered by <a href="https://codefixbug.com" target="_blank" style="color: #c0a16b"> Codefixbug Limited</a>
        </div>
    </div>
    </div>
</footer>

<!-- JAVASCRIPT -->
<script src="<?php echo e(asset('js/vendor/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vendor/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vendor/slick/slick.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/vendor/lity/lity.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<script src="<?php echo e(asset('js/mc/jquery.ketchup.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/mc/main.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
<script>
    $(document).ready(function(){
        // Add smooth scrolling to all links
        $("a").on('click', function(event) {

            // Make sure this.hash has a value before overriding default behavior
            if (this.hash !== "") {
                // Prevent default anchor click behavior
                event.preventDefault();

                // Store hash
                var hash = this.hash;

                // Using jQuery's animate() method to add smooth page scroll
                // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
                $('html, body').animate({
                    scrollTop: $(hash).offset().top
                }, 800, function(){

                    // Add hash (#) to URL when done scrolling (default click behavior)
                    window.location.hash = hash;
                });
            } // End if
        });
    });
</script>






<!-- Sign Up Modal -->
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5f4fda9e8e67d5cd"></script>

</body>


</html>

<?php /**PATH C:\Users\OHHJAY\Desktop\tribute\backend\resources\views/layouts/index.blade.php ENDPATH**/ ?>